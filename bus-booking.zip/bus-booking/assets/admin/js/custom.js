$(document).on('submit', '.database_operation_from', function () {
    const url = $(this).attr('data-url');
    const data = $(this).serialize();
    console.log(data);
    $.post(url, data, function (resp) {
        console.log(resp);
        let fb = JSON.parse(resp);
        console.log(fb)
        if (fb.status == 'true') {
            alert("Data Successfully Inserted");
            window.location.href = fb.reload;
        } else {
            alert('Please Try Again');
        }
    })
    return false;
});
$(document).on("change","manage_status",function(){
    const selector = $(this).attr("data-selecto");
    const url = $(this).attr("data-url");
    console.log(selector);
    console.log(url);
});